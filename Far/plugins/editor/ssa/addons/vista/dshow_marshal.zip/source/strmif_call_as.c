#include "strmif.h"

/* [local] */ HRESULT STDMETHODCALLTYPE ICaptureGraphBuilder_FindInterface_Proxy( 
    ICaptureGraphBuilder * This,
    /* [unique][in] */ const GUID *pCategory,
    /* [in] */ IBaseFilter *pf,
    /* [in] */ REFIID riid,
    /* [out] */ void **ppint)
{
	return ICaptureGraphBuilder_RemoteFindInterface_Proxy(This, pCategory, pf, riid, (IUnknown**)ppint);
}


/* [call_as] */ HRESULT STDMETHODCALLTYPE ICaptureGraphBuilder_FindInterface_Stub( 
    ICaptureGraphBuilder * This,
    /* [unique][in] */ const GUID *pCategory,
    /* [in] */ IBaseFilter *pf,
    /* [in] */ REFIID riid,
    /* [out] */ IUnknown **ppint)
{
	return This->lpVtbl->FindInterface(This, pCategory, pf, riid, (void**)ppint);
}



/* [local] */ HRESULT STDMETHODCALLTYPE ICaptureGraphBuilder2_FindInterface_Proxy( 
    ICaptureGraphBuilder2 * This,
    /* [in] */ const GUID *pCategory,
    /* [in] */ const GUID *pType,
    /* [in] */ IBaseFilter *pf,
    /* [in] */ REFIID riid,
    /* [out] */ void **ppint)
{
	return ICaptureGraphBuilder2_RemoteFindInterface_Proxy(This, pCategory, pType, pf, riid, (IUnknown**)ppint);
}

/* [call_as] */ HRESULT STDMETHODCALLTYPE ICaptureGraphBuilder2_FindInterface_Stub( 
    ICaptureGraphBuilder2 * This,
    /* [in] */ const GUID *pCategory,
    /* [in] */ const GUID *pType,
    /* [in] */ IBaseFilter *pf,
    /* [in] */ REFIID riid,
    /* [out] */ IUnknown **ppint)
{
	return This->lpVtbl->FindInterface(This, pCategory, pType, pf, riid, (void**)ppint);
}


/* [local] */ HRESULT STDMETHODCALLTYPE IKsPropertySet_Get_Proxy( 
    IKsPropertySet * This,
    /* [in] */ REFGUID guidPropSet,
    /* [in] */ DWORD dwPropID,
    /* [size_is][in] */ LPVOID pInstanceData,
    /* [in] */ DWORD cbInstanceData,
    /* [size_is][out] */ LPVOID pPropData,
    /* [in] */ DWORD cbPropData,
    /* [out] */ DWORD *pcbReturned)
{
	return IKsPropertySet_RemoteGet_Proxy(This, guidPropSet, dwPropID, 
		(byte *)pInstanceData, cbInstanceData,
		(byte *)pPropData, cbPropData,
		pcbReturned);
}


/* [call_as] */ HRESULT STDMETHODCALLTYPE IKsPropertySet_Get_Stub( 
    IKsPropertySet * This,
    /* [in] */ REFGUID guidPropSet,
    /* [in] */ DWORD dwPropID,
    /* [size_is][in] */ byte *pInstanceData,
    /* [in] */ DWORD cbInstanceData,
    /* [size_is][out] */ byte *pPropData,
    /* [in] */ DWORD cbPropData,
    /* [out] */ DWORD *pcbReturned)
{
	return This->lpVtbl->Get(This, guidPropSet, dwPropID,
		pInstanceData, cbInstanceData,
		pPropData, cbPropData, pcbReturned);
}


/* [local] */ HRESULT STDMETHODCALLTYPE IKsPropertySet_Set_Proxy( 
    IKsPropertySet * This,
    /* [in] */ REFGUID guidPropSet,
    /* [in] */ DWORD dwPropID,
    /* [size_is][in] */ LPVOID pInstanceData,
    /* [in] */ DWORD cbInstanceData,
    /* [size_is][in] */ LPVOID pPropData,
    /* [in] */ DWORD cbPropData)
{
	return IKsPropertySet_RemoteSet_Proxy(This, guidPropSet, dwPropID, 
        	(byte *)pInstanceData, cbInstanceData,
		(byte *)pPropData, cbPropData);
}

/* [call_as] */ HRESULT STDMETHODCALLTYPE IKsPropertySet_Set_Stub( 
    IKsPropertySet * This,
    /* [in] */ REFGUID guidPropSet,
    /* [in] */ DWORD dwPropID,
    /* [size_is][in] */ byte *pInstanceData,
    /* [in] */ DWORD cbInstanceData,
    /* [size_is][in] */ byte *pPropData,
    /* [in] */ DWORD cbPropData)
{
	return This->lpVtbl->Set(This, guidPropSet, dwPropID,
		pInstanceData, cbInstanceData,
		pPropData, cbPropData);
}

